#!/usr/bin/python

import sys

req = sys.stdin.read()
print "You said:", req
